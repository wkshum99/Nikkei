<html>
<body>

<form action='test.php' method='post'>
id : <input type='text' name='id'/><br />
password : <input type='text' name='password'/> <br />
<input type='submit' value='send'>
</form>

<?php
  $key = "hoge"; // 暗号化用のキー
  $message='login fail'; // 表示用メッセージ

  if (isset($_COOKIE['enc_id'])){ // クッキーのチェックと復号化
    $txt = openssl_decrypt(base64_decode($_COOKIE['enc_id']), 'aes-256-ecb', $key);
    $t = unpack("L", substr($txt, -4))[1];
    $id = bin2hex(substr($txt, 0, 7));
    $message = "already login($id) : " . date("Y-m-d H:i:s", $t);
  }

  if (isset($_POST['id']) && isset($_POST['password'])) { // 簡易的なログイン処理
    if ($_POST['id'] == '10' && $_POST['password'] == 'password') {

      // クッキーを[ランダム文字列+現在時刻]で生成
      $id = bin2hex(openssl_random_pseudo_bytes(8));
      $cookie = hex2bin($id) . pack('L', time());
      $enc_cookie = base64_encode(openssl_encrypt($cookie, 'aes-256-ecb', $key));
      // 暗号:enc_idと平文:idをクッキーに保存
      setcookie('enc_id', $enc_cookie, time()+60*60*24*14);
      setcookie('id', bin2hex($cookie), time()+60*60*24*14);

      $message='login success';
    }
  }
?>

<p><?php echo $message; ?></p>

</body>
</html>