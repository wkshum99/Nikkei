from flask import Flask
import os

def create_app():
    app = Flask(__name__)

    from . import books, authors #同じフォルダ内にあるモジュールbooksをを参照
    app.register_blueprint(books.bp)
    app.register_blueprint(authors.bp)

    app.config.from_mapping(
        SECRET_KEY='temp',
        DATABASE=os.path.join(app.instance_path, 'bookdb.sqlite3'),
    )

    from . import bookdb
    bookdb.init_app(app)

    @app.route('/test')
    def apptest():
        return 'アプリケーションセットアップ完了!'
      
    return app