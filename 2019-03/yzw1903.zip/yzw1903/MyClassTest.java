public class MyClassTest {
  public static void main(String[] args) {
    MyClass obj1 = MyClass.createInstance();
    MyClass obj2 = MyClass.createInstance();
    MyClass obj3 = MyClass.createInstance();
  }
}